let () =
  exit (Optmaindriver.main Sys.argv Format.err_formatter)
